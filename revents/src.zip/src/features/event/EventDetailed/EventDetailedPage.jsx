import React from 'react'

const EventDetailedPage = () => {
    return (
        <div>
            <h1>Event detailed Page</h1>
        </div>
    )
}

export default EventDetailedPage
