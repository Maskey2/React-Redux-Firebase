import React from 'react'

const UserDetailedPage = () => {
    return (
        <div>
            <h1>UserDetailedPage</h1>
        </div>
    )
}

export default UserDetailedPage
