import React from 'react'

const SettingsNav = () => {
    return (
        <div>
            <h1>SettingsNav</h1>
        </div>
    )
}

export default SettingsNav
