import React from 'react'

const BasicPage = () => {
    return (
        <div>
            <h1>BasicPage</h1>
        </div>
    )
}

export default BasicPage
