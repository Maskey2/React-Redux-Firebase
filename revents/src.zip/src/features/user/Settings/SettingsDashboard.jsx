import React from 'react'

const SettingsDashboard = () => {
    return (
        <div>
            <h1>SettingsDashboard</h1>
        </div>
    )
}

export default SettingsDashboard
