import React from 'react'

const AboutPage = () => {
    return (
        <div>
            <h1>AboutPage</h1>
        </div>
    )
}

export default AboutPage
