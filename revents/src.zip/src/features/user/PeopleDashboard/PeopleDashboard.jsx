import React from 'react'

const PeopleDashboard = () => {
    return (
        <div>
            <h1>PeopleDashboard</h1>
        </div>
    )
}

export default PeopleDashboard
